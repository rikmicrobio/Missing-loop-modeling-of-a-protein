struct mod_sequence {
%mutable;
  char *name, *source, *prottyp, *pdb_accession;
  float resol;
  float rfactr;
%immutable;
  int nres;
  int nseg;
  int dirty;
  struct mod_int1_array irestyp;
  struct mod_int1_array iress1;
  struct mod_int1_array iress2;
};
